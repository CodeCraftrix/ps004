<?php
// Retrieve form data
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$password = $_POST['password'];
$dob = $_POST['dob'];

// Create connection
$conn = new mysqli('localhost', 'zenlaptop', 'zenlaptop', 'zenlaptop');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected successfully.";

    $stmt = $conn->prepare("INSERT INTO registration (firstname, lastname, email, password, dob) VALUES (?, ?, ?, ?, ?, ?)");
    
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    } else {
        echo "Statement prepared successfully.";

        // Bind parameters
        $stmt->bind_param("ssssss", $firstname, $lastname, $email, $password, $dob);
        
        // Execute statement
        if ($stmt->execute()) {
            echo "Registration successful.";
        } else {
            die("Execute failed: " . $stmt->error);
        }

        // Close statement
        $stmt->close();
    }

    // Close connection
    $conn->close();
}
?>
