function validateEmail(email) {
    // Regular expression to check email format
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
  
  function validatePassword(password) {
    // Regular expression to check password strength (at least 8 characters, containing at least one uppercase letter, one lowercase letter, and one digit)
    var passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
    return passwordRegex.test(password);
  }
  
  function validateLogin() {
    var email = document.getElementById("loginEmail").value;
    var password = document.getElementById("loginPassword").value;
    var error = document.getElementById("loginError");
  
    error.innerHTML = "";
  
    if (!email || !password) {
      error.innerHTML = "Please fill in all fields.";
      return false;
    }
  
    if (!validateEmail(email)) {
      error.innerHTML = "Please enter a valid email address.";
      return false;
    }
  
    return true;
  }
  
  function validateSignup() {
    var email = document.getElementById("signupEmail").value;
    var password = document.getElementById("signupPassword").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var error = document.getElementById("signupError");
  
    error.innerHTML = "";
  
    if (!email || !password || !confirmPassword) {
      error.innerHTML = "Please fill in all fields.";
      return false;
    }
  
    if (!validateEmail(email)) {
      error.innerHTML = "Please enter a valid email address.";
      return false;
    }
  
    if (!validatePassword(password)) {
      error.innerHTML = "Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one digit.";
      return false;
    }
  
    if (password !== confirmPassword) {
      error.innerHTML = "Passwords do not match.";
      return false;
    }
  
    return true;
  }
  