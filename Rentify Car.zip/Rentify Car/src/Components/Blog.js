import React from 'react'

const Blog = () => {
  return (
    <div className="blog container mt-5">
      <div className="content text-center">
        <h3>Latest Blog Posts</h3>
        <i>Renting a car can be a convenient way to travel, but it’s important to be informed to avoid common pitfalls. This blog provides a comprehensive guide to renting cars, covering essential tips and considerations.</i>
      </div>
      <div className="row mt-5">
        <div className="col-lg-4 col-sm-12 mt-3">
          <div className="card">
            <div className="image" style={{width: "100%",height: "280px"}}>
            <img className="card-img-top" src="images/Best-Car-Blogs-Websites.jpeg" alt="Card image cap" width="100%" height="100%"/>
          </div>
            <div className="card-body">
              <h5 className="card-title">Audi S3</h5>
              <p className="card-text">This 2017 Audi S3 is a luxury sports car that’s perfect for a night out on the town. With its sleek design and powerful engine, you’ll enjoy a thrilling and exciting ride. The car’s advanced navigation system and premium sound system also make for a comfortable driving experience.</p>
              <a href="#" className="btn btn-primary">Go somewhere</a>
            </div>
          </div>
        </div>
        <div className="col-lg-4 col-sm-12 mt-3">
          <div className="card">
            <div className="image" style={{width: "100%",height: "280px"}}>
            <img className="card-img-top" src="images/Blog1.jpeg" alt="Card image cap" width="100%" height="100%"/>
          </div>
            <div className="card-body">
              <h5 className="card-title">Toyota Prius</h5>
              <p className="card-text">If you’re looking for a fuel-efficient car for your daily commute, this 2020 Toyota Prius is a great option. With a hybrid engine, you’ll save money on gas while still enjoying a comfortable and smooth ride. The car’s advanced safety features also make it a smart and secure choice.</p>
              <a href="#" className="btn btn-primary">Go somewhere</a>
            </div>
          </div>
        </div>
        <div className="col-lg-4 col-sm-12 mt-3">
          <div className="card">
            <div className="image" style={{width: "100%",height: "280px"}}>
            <img className="card-img-top" src="images/Blog2.jpeg" alt="Card image cap" width="100%" height="100%"/>
          </div>
            <div className="card-body">
              <h5 className="card-title">Polaris Slingshot</h5>
              <p className="card-text">For a fun and unique driving experience, rent this 2018 Polaris Slingshot. With its three-wheeled design and open-air cockpit, you’ll enjoy a thrilling and exciting ride. The car’s advanced sound system and Bluetooth connectivity also make it easy to enjoy your favorite tunes.</p>
              <a href="#" className="btn btn-primary">Go somewhere</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Blog