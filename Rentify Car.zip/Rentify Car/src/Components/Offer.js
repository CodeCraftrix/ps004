import React from 'react'

const Offer = (props) => {
  return (
    <div className="container-fluid mt-5 p-4" style={{ backgroundColor:"rgba(237, 234, 234, 0.848)!important" }}>
        <div className="container offers">
        <div>
      {props.condition && (
        <div className="content text-center">
          <h3>Offers</h3>
          <i>This sleek and sporty 2018 BMW 430i is the perfect car for a weekend getaway. With a turbocharged engine, you’ll enjoy plenty of power while driving down the highway. The car’s leather seats and premium sound system make for a comfortable and enjoyable ride.</i>
        </div>
      )}
    </div>
          <div className="row mt-4">
            <div className="col-lg-4">
              <div className="card border-0 mt-5" style={{   backgroundColor: "rgb(207, 204, 204);" }}>
                <div className="card-img bg-white" style={{ width: "100%",height: "250px" }}>
                <img className="card-img-top" src="images/Car-Download-PNG.png" alt="Card image cap" width="100%" />
              </div>
                <div className="card-body p-3  bg-white">
                  <h5 className="card-title"> BMW 430i </h5>
                  <p className="card-text">This sleek and sporty 2018 BMW 430i is the perfect car for a weekend getaway. With a turbocharged engine, you’ll enjoy plenty of power while driving down the highway. The car’s leather seats and premium sound system make for a comfortable and enjoyable ride.</p>
                
                </div>
                <a href="#" className="btn btn-block bg-white" style={{ borderRadius:"0",marginTop: "1px" }}>Go somewhere</a>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="card border-0 mt-5" style={{   backgroundColor: "grey" }}>
                <div className="card-img bg-white" style={{ width: "100%",height: "250px" }}>
                <img className="card-img-top" src="images/sports-cars.png" alt="Card image cap" width="100%" />
              </div>
                <div className="card-body p-3  bg-white">
                  <h5 className="card-title">Tesla Model Y</h5>
                  <p className="card-text">This 2020 Tesla Model Y is the ultimate electric SUV. With a range of over 300 miles and an acceleration time of 0-60 in just 3.5 seconds, you’ll have plenty of power and range for your daily commute or weekend road trip. The car’s advanced autopilot features also make driving a breeze.</p>
                
                </div>
                <a href="#" className="btn btn-block bg-white" style={{ borderRadius:"0",marginTop: "1px" }}>Go somewhere</a>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="card border-0 mt-5" style={{   backgroundColor: "grey" }}>
                <div className="card-img bg-white" style={{ width: "100%",height: "250px" }}>
                <img className="card-img-top" src="images/ford-edge-orange.png" alt="Card image cap" width="100%" />
              </div>
                <div className="card-body p-3  bg-white">
                  <h5 className="card-title">Audi S3</h5>
                  <p className="card-text">This 2017 Audi S3 is a luxury sports car that’s perfect for a night out on the town. With its sleek design and powerful engine, you’ll enjoy a thrilling and exciting ride. The car’s advanced navigation system and premium sound system also make for a comfortable and enjoyable driving experience.</p>
                
                </div>
                <a href="#" className="btn btn-block bg-white" style={{ borderRadius:"0",marginTop: "1px" }}>Go somewhere</a>
              </div>
            </div>
          </div>

        </div>
    </div>
  )
}

export default Offer